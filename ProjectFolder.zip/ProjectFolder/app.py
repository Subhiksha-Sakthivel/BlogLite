from flask import Flask, render_template, request, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField
from wtforms.validators import DataRequired, EqualTo, Length, ValidationError
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_migrate import Migrate
from wtforms.widgets import TextArea
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SECRET_KEY'] = "Shoto@11"
db = SQLAlchemy(app)
migrate = Migrate(app,db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(int(user_id))

class SearchForm(FlaskForm):
    searched = StringField("Searched", validators=[DataRequired()])
    submit = SubmitField("Submit")

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Submit")

@app.route('/login', methods=['GET','POST'])
def login():
    err_msg=None
    form =LoginForm()
    if form.validate_on_submit():
        user = Users.query.filter_by(username=form.username.data).first()
        if user:
            if user.password == form.password.data:
                login_user(user)
                return redirect(url_for('feed'))
            else:
                err_msg = 'Incorrect Password was Entered'
                form.password.data =''
        else:
            err_msg = 'Entered Username isnt Registered'
            form.username.data =''
            form.password.data =''
    return render_template('login.html', form=form, err_msg=err_msg)


@app.route('/logout', methods=['GET','POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/feed', methods=['GET','POST'])
@login_required
def feed():
    blog = Blogs.query.filter_by(blogger_id=current_user.id).all()
    folr = Follow.query.filter_by(Follower=current_user.username).all()
    for i in folr:
        user = Users.query.filter_by(username=i.Followed).first()
        blog+=Blogs.query.filter_by(blogger_id=user.id).all()
    blog.sort(key=lambda x:x.Timestamp,reverse=True)
    return render_template("feed.html", blog=blog)

@app.route('/view', methods=['GET','POST'])
@login_required
def profile_view():
    blog = Blogs.query.filter_by(blogger_id=current_user.id).all()
    return render_template('profile_view.html',blog=blog)

@app.route('/view_other/<name>', methods=['GET','POST'])
@login_required
def other_profile_view(name):
    user = Users.query.filter_by(username=name).first()
    blog = Blogs.query.filter_by(blogger_id=user.id).all()
    return render_template('profile_view_other.html',blog=blog, user=user)

class Follow(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    Follower = db.Column(db.String(200), db.ForeignKey('users.username'))
    Followed = db.Column(db.String(200), db.ForeignKey('users.username'))

class Users(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(200),nullable = False,unique=True)
    username = db.Column(db.String(200), nullable =False, unique = True )
    Bio = db.Column(db.String(150))
    password = db.Column(db.String(20), nullable =False)
    nof = db.Column(db.Integer, default=0)
    following = db.Column(db.Integer, default=0)
    nop = db.Column(db.Integer, default=0)
    blogs = db.relationship('Blogs', backref='blogger', cascade="all, delete-orphan")

    def __repr__(self):
        return '<Name %r>' % self.username

class Blogs(db.Model):
    ID = db.Column(db.Integer, primary_key=True)
    Title = db.Column(db.String(200), nullable= False)
    Caption = db.Column(db.Text, nullable= False)
    ImageUrl=db.Column(db.String(2048))
    Timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    blogger_id = db.Column(db.Integer, db.ForeignKey('users.id'))

class UserForm(FlaskForm):
    Name = StringField('Name',validators=[DataRequired()])
    username = StringField('Username',validators=[DataRequired()])
    Bio = StringField('Bio')
    password = PasswordField('Password',validators=[DataRequired(), EqualTo('repass', message='Passwords must match'), 
        Length(min=8,message="Length of PAssword must be atleast 8 characters")])
    repass = PasswordField('Confirm Password', validators=[DataRequired()])
    submit = SubmitField("Submit")

    def validate_username(self,username):
        excluded_chars = " *?!'^+%&/\:;,-+<>~`()=}][{$#@"
        for char in self.username.data:
            if char in excluded_chars:
                raise ValidationError(
                    f"Character {char} is not allowed in username.")


class BlogForm(FlaskForm):
    Title = StringField('Title',validators=[DataRequired()])
    Caption = StringField('Caption',validators=[DataRequired()], widget=TextArea())
    ImageUrl = StringField('ImageUrl')
    submit = SubmitField("Submit")


@app.route('/blogs/<int:id>')
@login_required
def blog_details(id):
    blog = Blogs.query.get_or_404(id)
    return render_template("blog_details.html", blogs=blog)

@app.route('/follow/<int:id>')
@login_required
def follow(id):
    user2 = Users.query.get_or_404(id)
    obj = Follow.query.filter_by(Follower=current_user.username)
    obj = obj.filter_by(Followed=user2.username).first()
    if obj == None:
        obj = Follow(Follower=current_user.username, Followed=user2.username)
        user1 = Users.query.get_or_404(current_user.id)
        user2.nof = user2.nof+1
        user1.following = user1.following+1
        db.session.add(user1)
        db.session.add(user2)
        db.session.add(obj)
        db.session.commit()
        return redirect(url_for('profile_view'))
    else:
        err="Cannot Follow!!"
        msg="You are already Following this user"
        return render_template("errormsg.html",msg=msg, err=err)

@app.route('/followed/<int:id>')
def followed(id):
    user = Users.query.get_or_404(id)
    fous = Follow.query.filter_by(Follower=user.username).all()
    return render_template("followed.html", fous=fous)

@app.route('/followedby/<int:id>')
def followed_by(id):
    user = Users.query.get_or_404(id)
    fous = Follow.query.filter_by(Followed=user.username).all()
    return render_template("followed_by.html", fous=fous)

@app.route('/unfollow/<int:id>')
@login_required
def unfollow(id):
        user2 = Users.query.get_or_404(id)
        obj = Follow.query.filter_by(Follower=current_user.username)
        obj = obj.filter_by(Followed=user2.username).first()
        if obj != None:
            user1 = Users.query.get_or_404(current_user.id)
            user2.nof = user2.nof-1
            user1.following = user1.following-1
            db.session.add(user1)
            db.session.add(user2)
            db.session.delete(obj)
            db.session.commit()
            return redirect(url_for('profile_view'))
        else:
            err="Cannot Unfollow!!"
            msg="You arent Following this user"
            return render_template("errormsg.html",msg=msg, err=err)


@app.route('/blogs')
@login_required
def blogs():
    blog = Blogs.query.order_by(Blogs.Timestamp)
    return render_template("blogs.html",blogs=blog)


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


@app.errorhandler(500)
def page_not_found(e):
    return render_template("500.html"), 500


@app.route('/',methods=['GET','POST'])
def add_user():
    username = None
    err_msg=None
    form = UserForm()
    if form.validate_on_submit():
        user = Users.query.filter_by(username=form.username.data).first()
        if user is None:
            user = Users(Name= form.Name.data, username = form.username.data, Bio=form.Bio.data, password = form.password.data)
            db.session.add(user)
            db.session.commit()
            username = form.username.data
        else:
            err_msg="Username already exists"
            username = None
        form.Name.data = ''
        form.username.data = ''
        form.Bio.data = ''
        form.password.data = ''
    our_users = Users.query
    return render_template("add_user.html", form = form, name=username, our_users=our_users, err_msg=err_msg)


@app.route('/update/<int:id>', methods=['GET','POST'])
@login_required
def update(id):
    form = UserForm()
    err_msg = None
    edit_user = Users.query.get_or_404(id)
    if request.method =="POST":
        edit_user.Name = request.form['Name']
        edit_user.username = request.form['username']
        edit_user.Bio = request.form['Bio']
        edit_user.password = request.form['password']
        try:
            db.session.commit()
            form.Name.data = edit_user.Name
            form.username.data = edit_user.username
            form.Bio.data = edit_user.Bio
            return redirect(url_for('profile_view'))
        except:
            err_msg="Couldnt Update. Please Try Again"
            form.Name.data = edit_user.Name
            form.username.data = edit_user.username
            form.Bio.data = edit_user.Bio
            return render_template("update.html", form=form,
            eu = edit_user, err_msg=err_msg)
    else:
        form.Name.data = edit_user.Name
        form.username.data = edit_user.username
        form.Bio.data = edit_user.Bio
        return render_template("update.html", form=form,
            eu = edit_user)


@app.route('/blogs/edit/<int:id>',methods = ['GET','POST'])
def edit(id):
    blog = Blogs.query.get_or_404(id)
    form = BlogForm()
    if form.validate_on_submit():
        blog.Title = form.Title.data
        blog.Caption = form.Caption.data
        blog.ImageUrl = form.ImageUrl.data
        db.session.add(blog)
        db.session.commit()
        return redirect(url_for('blog_details',id=blog.ID))
    if current_user.id == blog.blogger_id:
        form.Title.data = blog.Title
        form.Caption.data = blog.Caption
        form.ImageUrl.data = blog.ImageUrl
        return render_template("edit.html", form = form, id=blog.ID)
    else:
        err="Access Denied"
        msg="You aren't Authorized to edit the Blog"
        return render_template("errormsg.html",msg=msg, err=err)


@app.route('/delete/<int:id>')
@login_required
def delete(id):
    err_msg=None
    if id == current_user.id:
        un = None
        form = UserForm()
        del_user = Users.query.get_or_404(id)
        folr = Follow.query.filter_by(Follower=current_user.username).all()
        fold = Follow.query.filter_by(Followed=current_user.username).all()
        for i in folr:
            user = Users.query.filter_by(username=i.Followed).first()
            unfollow(user.id)
        for j in fold:
            user1 = Users.query.filter_by(username=j.Follower).first()
            obj = Follow.query.filter_by(Follower=user1.username)
            obj = obj.filter_by(Followed=current_user.username).first()
            user2 = Users.query.get_or_404(current_user.id)
            user2.nof = user2.nof-1
            user1.following = user1.following-1
            db.session.add(user1)
            db.session.add(user2)
            db.session.delete(obj)
            db.session.commit()
        try:
            db.session.delete(del_user)
            db.session.commit()
            our_users = Users.query
            return render_template("add_user.html", form = form, name=un, our_users=our_users, err_msg=err_msg)
        except:
            err_msg = "Couldnt Delete the user due to some error. Please Try again"
            return render_template("add_user.html", form = form, name=un, our_users=our_users, err_msg=err_msg)
    else:
       err="Access Denied"
       msg="You aren't Authorized to delete the Profile"
       return render_template("errormsg.html",msg=msg, err=err) 


@app.route('/add_blog', methods=['GET','POST'])
def add_blog():
    form = BlogForm()
    if form.validate_on_submit():
        blogger = current_user.id
        blog = Blogs(Title=form.Title.data, Caption=form.Caption.data, ImageUrl=form.ImageUrl.data, blogger_id=blogger)
        form.Title.data=''
        form.Caption.data=''
        form.ImageUrl.data=''
        user = Users.query.get_or_404(blogger)
        user.nop=user.nop+1
        db.session.add(user)
        db.session.add(blog)
        db.session.commit()
    return render_template("add_blog.html",form=form)

@app.route('/blogs/delete/<int:id>')
@login_required
def delete_blog(id):
    err_msg = None
    del_blog = Blogs.query.get_or_404(id)
    id = current_user.id
    if id == del_blog.blogger.id:
        try:
            current_user.nop=current_user.nop-1
            db.session.delete(del_blog)
            db.session.commit()
            blog = Blogs.query.order_by(Blogs.Timestamp)
            return render_template("blogs.html",blogs=blog, err_msg=err_msg)
        except:
            err_msg = "Couldnt delete the blog. Please Try again"
            blog = Blogs.query.order_by(Blogs.Timestamp)
            return render_template("blogs.html",blogs=blog,err_msg=err_msg)
    else:
        err="Access Denied"
        msg="You aren't Authorized to delete the Blog"
        return render_template("errormsg.html",msg=msg, err=err)

@app.context_processor
def base():
    form = SearchForm()
    return dict(form=form)

@app.route('/search', methods=['POST'])
@login_required
def search():
    form = SearchForm()
    if form.validate_on_submit():
        post_searched = form.searched.data
        search_users = Users.query
        search_users = search_users.filter(Users.username.like('%' + post_searched + '%')).all()
        return render_template("search.html", form=form, searched=post_searched, search_users=search_users)
